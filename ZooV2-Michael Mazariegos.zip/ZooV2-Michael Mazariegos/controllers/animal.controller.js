"use strict";

var Animal = require("../models/animal.model");

function saveAnimal(req, res) {
    var animal = new Animal();
    var params = req.body;

    if (params.name && params.nickName && params.age) {
        animal.name = params.name;
        animal.nickName = params.nickName;
        animal.age = params.age;
        animal.carer = params.carer;
        User.findOne({ nickName: params.nickName }, (err, ok) => {
            if (err) {
                res.status(500).send({ message: "Error general" });
            } else if (ok) {
                res.send({ message: "Ya existe un animal con ese apodo" });
            } else {
                animal.save((err, savedAnimal) => {
                    if (err) {
                        res.status(500).send({
                            message: "Error general al guardar animal"
                        });
                    } else if (userSaved) {
                        res.send({ message: "Animal creado", user: userSaved });
                    } else {
                        res.status(404).send({ message: "Animal no guardado" });
                    }
                });
            }
        });
    } else {
        res.status(404).send({ message: "Ingrese los datos minimos" });
    }
}

function updateAnimal(req, res) {
    var animalId = req.params.id;
    var update = req.body;
    Animal.findByIdAndUpdate(
        animalId,
        update,
        { new: true },
        (err, animalUpdated) => {
            if (err) {
                res.status(500).sen({ message: "Error general" });
            } else if (animalUpdated) {
                res.send({ message: "Animal actualizado", animalUpdated });
            } else {
                res.status(404).send({
                    message: "No se pudo actualizar el animal"
                });
            }
        }
    ).populate("users");
}

function deleteAnimal(req, res) {
    var animalID = req.params.id;
    Animal.findByIdAndDelete(userId, (err, animalDeleted) => {
        if (err) {
            res.status(500).send({ message: "Error general" });
        } else if (animalDeleted) {
            res.send({ message: "Animal eliminado" });
        } else {
            res.status(404).send({ message: "No se pudo eliminar el animal" });
        }
    });
}

function uploadAnimal(req, res) {
    var animalId = req.params.id;
    var fileName = "No se ah subido";
    if (req.files) {
        var filePath = req.files.image.path;
        var fileSplit = filePath.split("\\");
        var fileName = fileSplit[2];

        var ext = fileName.split(".");
        var fileExt = ext[1];

        if (
            fileExt == "png" ||
            fileExt == "jpg" ||
            fileExt == "jpeg" ||
            fileExt == "gif"
        ) {
            Animal.findByIdAndUpdate(
                animalId,
                { image: fileName },
                { new: true },
                (err, animalUpdated) => {
                    if (err) {
                        res.status(500).send({ message: " Error general" });
                    } else if (userUpdated) {
                        res.send({
                            useanimal: animalUpdated,
                            image: animalUpdated.image
                        });
                    } else {
                        res.status(418).send({
                            message: "No se ha podido actualizar"
                        });
                    }
                }
            );
        } else {
            fs.unlink(filePath, err => {
                if (err) {
                    res.status(418).send({
                        message:
                            "Extensión de archivo no admitida, y archivo no eliminado"
                    });
                } else {
                    res.send({ message: "Extensión de archivo no admitida" });
                }
            });
        }
    } else {
        res.status(404).send({ message: "No has subido una imagen" });
    }
}

function getImage(req, res) {
    var animalId = req.params.id;
    var fileName = req.params.image;
    var pathFile = "./uploads/animals/" + fileName;

    fs.exists(pathFile, exists => {
        if (exists) {
            res.sendFile(path.resolve(pathFile));
        } else {
            res.status(404).send({ message: "La imagen no existe" });
        }
    });
}

function listAnimals(req, res) {
    var params = req.body;
    Animal.find((err, animals) => {
        if (err) {
            res.status(500).send({ message: "Error general" });
        } else if (animals) {
            res.send({ message: "Lista de animales", animals });
        } else {
            res.status(500).send({ message: "No se encontro ningun animal" });
        }
    }).populate("users");
}

function searchAnimal(req, res) {
    var params = req.body;
    if (params.search) {
        Animal.find({ $or: [{ _id: params.search }] }, (err, animalFind) => {
            if (err) {
                res.status(500).send({ message: "Error general" });
            } else if (animalFind) {
                res.send({
                    message: "Coincidencias encontradas",
                    animal: animalFind
                });
            } else {
                res.status(418).send({ message: "Sin coincidencias" });
            }
        });
    } else {
        res.send({ message: "Ingrese el campo de busqueda" });
    }
}

module.exports = {
    saveAnimal,
    updateAnimal,
    deleteAnimal,
    uploadAnimal,
    getImage,
    listAnimals,
    searchAnimal
};
