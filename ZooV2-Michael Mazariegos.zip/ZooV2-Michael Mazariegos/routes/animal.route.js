"use strict";

var express = require("express");
var animalController = require("../controllers/animal.controller");
var api = express.Router();
var mdAuth = require("../middlewares/authenticated");
var connectMultiparty = require("connect-multiparty");
var mdUpload = connectMultiparty({ uploadDir: "./uploads/animals" });

api.get(
    "/pruebaMiddleware",
    mdAuth.ensureAuthAdmin,
    animalController.pruebaMiddleware
);
api.post("/saveAnimal", mdAuth.ensureAuthAdmin, animalController.saveAnimal);
api.put(
    "/updateAnimal/:id",
    mdAuth.ensureAuthAdmin,
    animalController.updateAnimal
);
api.delete(
    "/deleteAnimal/:id",
    mdAuth.ensureAuthAdmin,
    animalController.deleteAnimal
);
api.put(
    "/uploadImage/:id",
    [mdAuth.ensureAuthAdmin, mdUpload],
    animalController.uploadImage
);
api.get(
    "/getImage/:id/:image",
    [mdAuth.ensureAuthAdmin, mdUpload],
    animalController.getImage
);
api.get("/listAnimals", animalController.listAnimals);

module.exports = api;
