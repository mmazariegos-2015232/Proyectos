"use strict";

var jwt = require("jwt-simple");
var moment = require("moment");
var key = "clave_super_secreta_tweet";

exports.ensureAuth = (req, res, next) => {
  var params = req.body;
  var parameters = [];
  var separate = [];
  if (params.command != null) {
    parameters.push(params.command.split(" "));
    parameters[0].forEach((Element) => {
      separate.push(Element);
    });

    if (separate[0] == "LOGIN" || separate[0] == "REGISTER") {
      next();
    } else {
      if (!req.headers.authorization) {
        console.log(separate[0]);
        return res.status(403).send({ message: "Peticion sin autenticacion" });
      } else {
        var token = req.headers.authorization.replace(/['"]+/g, "");
        try {
          var payload = jwt.decode(token, key);
          if (payload.exp <= moment().unix()) {
            return res.status(401).send({ message: "Token expirado" });
          }
        } catch (ex) {
          return res.status(404).send({ message: "Token no valido" });
        }

        req.user = payload;
        next();
      }
    }
  }
};
