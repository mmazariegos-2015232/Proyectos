var User = require("../models/user.model");
var Tweet = require("../models/tweet.model");
var bcrypt = require("bcrypt-nodejs");
var jwt = require("../services/jwt");

function commands(req, res) {
  var params = req.body;
  var command = req.body.command;
  var separate = command.split(" ");

  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ crear usuario +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  if (separate[0] == "REGISTER") {
    var user = new User();
    var name = separate[1];
    var email = separate[2];
    var username = separate[3];
    var password = separate[4];

    if (name != null && email != null && username != null) {
      User.findOne(
        {
          $or: [{ name: name }, { email: email }, { username: username }],
        },
        (err, saveOk) => {
          if (err) {
            res.status(500).send({ message: "Intentalo mas tarde.", err });
          } else if (saveOk) {
            res.status(200).send({ message: "Usuario o correo en uso.", err });
          } else {
            user.name = name;
            user.email = email;
            user.username = username;
            /* user.followers = followers;
            user.followed = followed; */

            bcrypt.hash(password, null, null, (err, passwordHash) => {
              if (err) {
                res
                  .status(500)
                  .send({ message: "Error al encriptar Contraseña" });
              } else if (passwordHash) {
                user.password = passwordHash;

                user.save((err, userSave) => {
                  if (err) {
                    res
                      .status(500)
                      .send({ message: "Error general al guardar cambios" });
                  } else if (userSave) {
                    res
                      .status(200)
                      .send({ message: "Usuario Creado", user: userSave });
                  } else {
                    res.status(404).send({ message: "Usuario no guardado" });
                  }
                });
              } else {
                res.status(418).send({ message: "Error Inesperado" });
              }
            });
          }
        }
      );
    } else {
      res.send({ message: res });
    }
  }

  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ crear usuario +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

  if (separate[0] == "LOGIN") {
    var username = separate[1];
    var password = separate[2];

    if (username != null) {
      User.findOne(
        {
          $or: [{ username: username }, { email: email }],
        },
        (err, check) => {
          if (err) {
            res.status(500).send({ message: "Error general" });
          } else if (check) {
            bcrypt.compare(password, check.password, (err, passworOk) => {
              if (err) {
                res.status(500).send({
                  message: "Error al comparar",
                });
              } else if (passworOk) {
                if ((params.gettoken = true)) {
                  res.send({
                    token: jwt.createToken(check),
                  });
                } else {
                  res.send({
                    message: "Bienvenido.",
                    user: check,
                  });
                }
              } else {
                res.send({
                  message: "Contraseña incorrecta.",
                });
              }
            });
          } else {
            res.send({ message: "Datos de usuario incorrectos." });
          }
        }
      );
    } else {
      res.send({ message: "Ingresa todos los datos." });
    }
  }

  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ ver perfil de usuario +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

  if (separate[0] == "PROFILE") {
    var username = separate[1];

    User.find(
      {
        $or: [{ username: { $regex: "^" + separate[1], $options: "i" } }],
      },
      (err, userFind) => {
        if (err) {
          res.status(404).send({ message: "Error general.", err });
        } else if (userFind) {
          res.send({ profile: "Perfil:", userFind });
        } else {
          res.send({ message: "Ingrese el nombre del usuario." });
        }
      }
    );
  }

  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Seguir usuario +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  if (separate[0] == "FOLLOW") {
    var username = separate[1];

    if (separate.length == 2) {
      User.findOne({ username: username }, (err, userFound) => {
        if (err) {
          res.status(500).send({ message: "Error " + err });
        } else if (userFound) {
          if (req.user.username != userFound.username) {
            User.findOne(
              { _id: req.user.sub, followers: userFound._id },
              (err, userFind) => {
                if (err) {
                  res.status(500).send({ message: "Error " + err });
                } else if (userFind) {
                  res
                    .status(200)
                    .send({ message: "Ya estas siguiendo a este usuario" });
                } else {
                  User.findByIdAndUpdate(
                    req.user.sub,
                    { $push: { followers: userFound._id } },
                    { new: true },
                    (err, followedAdded) => {
                      if (err) {
                        res.status(500).send({ message: "Error " + err });
                      } else if (followedAdded) {
                        User.findByIdAndUpdate(
                          userFound._id,
                          { $push: { followed: req.user.sub } },
                          { new: true },
                          (err, succed) => {
                            if (err) {
                              res.status(500).send({ message: "Error " + err });
                            } else if (succed) {
                              res.send({ Follow: userFound.username });
                            } else {
                              res.status(500).send({
                                message: "No se pudo ejecutar el proceso.",
                              });
                            }
                          }
                        );
                      } else {
                        res.status(500).send({
                          message: "No se pudo ejecutar el proceso.",
                        });
                      }
                    }
                  );
                }
              }
            );
          } else {
            res.status(200).send({ message: "No puedes seguirte a ti mismo" });
          }
        } else {
          res.status(404).send({ message: "No se encontraron coincidencias" });
        }
      });
    } else {
      res.send({ message: "No se han ingresado los parametros necesarios." });
    }
  }

  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Dejar de seguir usuario +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  if (separate[0] == "UNFOLLOW") {
    var username = separate[1];

    if (separate.length == 2) {
      User.findOne({ username: username }, (err, userFound) => {
        if (err) {
          res.status(500).send({ message: "Error " + err });
        } else if (userFound) {
          if (req.user.username != userFound.username) {
            User.findOne(
              { _id: req.user.sub, followers: userFound._id },
              (err, userFind) => {
                if (err) {
                  res.status(500).send({ message: "Error " + err });
                } else if (userFind) {
                  User.findByIdAndUpdate(
                    req.user.sub,
                    { $pull: { followers: userFound._id } },
                    { new: true },
                    (err, unfollowedAdded) => {
                      if (err) {
                        res.status(500).send({ message: "Error " + err });
                      } else if (unfollowedAdded) {
                        User.findByIdAndUpdate(
                          userFound._id,
                          { $pull: { followed: req.user.sub } },
                          { new: true },
                          (err, succed) => {
                            if (err) {
                              res.status(500).send({ message: "Error " + err });
                            } else if (succed) {
                              res.send({ UNFOLLOW: userFound.username });
                            } else {
                              res.status(500).send({
                                message: "No se pudo ejecutar el proceso.",
                              });
                            }
                          }
                        );
                      } else {
                        res.status(500).send({
                          message: "No se pudo ejecutar el proceso.",
                        });
                      }
                    }
                  );
                } else {
                  res.status(200).send({
                    message:
                      "Aun no estas siguiendo a este usuario, asi que no puedes dejar de seguirlo.",
                  });
                }
              }
            );
          } else {
            res.status(200).send({ message: "No puedes seguirte a ti mismo" });
          }
        } else {
          res.status(404).send({ message: "No se encontraron coincidencias" });
        }
      });
    } else {
      res.send({ message: "No se han ingresado los parametros necesarios." });
    }
  }

  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Agregar tweet +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  if (separate[0] == "ADD_TWEET") {
    var tweet = new Tweet();
    var userId = req.user.sub;
    if (separate[1] != null) {
      tweet.author = userId;
      var cadena = "";
      for (var i in separate) {
        if (i >= 2) {
          var palabra = separate[i];
          cadena = cadena + " " + palabra;
          i++;
        }
      }
      tweet.text = cadena;

      tweet.save((err, tweetPosted) => {
        if (err) {
          res.status(404).send({ message: "Error general.", err });
        } else if (tweetPosted) {
          User.findByIdAndUpdate(
            userId,
            { $push: { tweets: tweetPosted._id } },
            { new: true },
            (err, userPostTweet) => {
              if (err) {
                res.status(404).send({ message: "Error general.", err });
              } else if (userPostTweet) {
                res.send({
                  message: "Tweet publicado.",
                  userPostTweet /* ,
                  tweetPosted, */,
                });
              } else {
                res.send({ message: "Error fuera de lo comun.", err });
              }
            }
          ).populate("tweets");
        } else {
          res.send({ message: "Error inesperado.", err });
        }
      });
    } else {
      res.send({
        message: "Escribe algo dentro del tweet para poder publicarlo.",
      });
    }
  }

  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Editar tweet +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  if (separate[0] == "EDIT_TWEET") {
    var userId = req.user.sub;
    var tweetID = separate[1];
    var text = separate[2];

    if (tweetID != null && text != null) {
      Tweet.findById(tweetID, (err, tweetFound) => {
        if (err) {
          res.status(404).send({ message: "Error general.", err });
        } else if (tweetFound) {
          if (tweetFound.author == userId) {
            var cadena = "";
            for (var i in separate) {
              if (i >= 2) {
                var palabra = separate[i];
                cadena = cadena + " " + palabra;
                i++;
              }
            }
            tweetFound.text = cadena;

            Tweet.findByIdAndUpdate(
              tweetID,
              { text: cadena },
              { new: true },
              (err, tweetUpdated) => {
                if (err) {
                  res.status(404).send({ message: "Error general.", err });
                } else if (tweetUpdated) {
                  res.send({ updated: "Tweet actualizado.", tweetUpdated });
                } else {
                  res.send({ message: "Error inesperado." });
                }
              }
            );
          } else {
            res.send({
              violation: "No tienes permitido realizar esta accion.",
            });
          }
        } else {
          res
            .status(404)
            .send({ message: "No se han encontrado coincidencias." });
        }
      });
    } else {
      res.status(418).send({ message: "Llene todos los parametros." });
    }
  }

  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Eliminar tweet +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  if (separate[0] == "DELETE_TWEET") {
    var userId = req.user.sub;
    var tweetID = separate[1];

    if (tweetID != null) {
      Tweet.findById(tweetID, (err, tweetFound) => {
        if (err) {
          res.status(404).send({ message: "Error general.", err });
        } else if (tweetFound) {
          if (tweetFound.author == userId) {
            User.findOneAndUpdate(
              { _id: userId, tweets: tweetID },
              { $pull: { tweets: tweetID } },
              { new: true },
              (err, userDeleteTweet) => {
                if (err) {
                  res.status(404).send({ message: "Error general.", err });
                } else if (userDeleteTweet) {
                  Tweet.findByIdAndRemove(tweetID, (err, tweetRemoved) => {
                    if (err) {
                      res
                        .status(404)
                        .send({ message: "Error de servidor.", err });
                    } else if (tweetRemoved) {
                      res.send({ Removed: userDeleteTweet });
                    } else {
                      res.status(418).send({
                        message: "No ha sido posible eliminar el tweet",
                        err,
                      });
                    }
                  });
                } else {
                  res.send({ message: "Error fuera de lo comun.", err });
                }
              }
            );
          } else {
            res.send({
              violation: "No tienes permitido realizar esta accion.",
            });
          }
        } else {
          res
            .status(404)
            .send({ message: "No se han encontrado coincidencias." });
        }
      });
    } else {
      res.send({
        message: "Debes colocar el ID de tu tweet para poder borrarlo.",
      });
    }
  }
  /* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Listar tweet +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
  if (separate[0] == "VIEW_TWEETS") {
    var username = separate[1];

    User.find(
      {
        $or: [{ username: { $regex: "^" + separate[1], $options: "i" } }],
      },
      (err, userFind) => {
        if (err) {
          res.status(404).send({ message: "Error general.", err });
        } else if (userFind) {
          res.send({ tweets: "Perfil:", userFind });
        } else {
          res.send({ message: "Ingrese el nombre del usuario." });
        }
      }
    ).populate("tweets");
  }
}

module.exports = {
  commands,
};
