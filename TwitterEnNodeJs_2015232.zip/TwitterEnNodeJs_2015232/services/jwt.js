"use strict";

var jwt = require("jwt-simple");
var moment = require("moment");
var key = "clave_super_secreta_tweet";

exports.createToken = (user) => {
  var payload = {
    sub: user._id,
    name: user.name,
    lastname: user.lastname,
    username: user.username,
    password: user.password,
    followers: user.followers,
    followed: user.followed,
    phone: user.phone,
    email: user.email,
    address: user.address,
    iat: moment().unix(),
    exp: moment().add(1, "days").unix(),
  };
  return jwt.encode(payload, key);
};
