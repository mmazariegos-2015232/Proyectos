"use strict";

var mongoose = require("mongoose");
var port = 3800;
var app = require("./app");

mongoose.Promise = global.Promise;

mongoose
  .connect("mongodb://localhost:27017/DBTWITTER", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
  })
  .then(() => {
    console.log("Conexion exitosa a la base de datos");
    app.listen(port, () => {
      console.log("Servidor corriendo en el puerto", port);
      console.log(
        "Para ejecutar las intrucciones se debe colocar la palabra (command) en el key de postman, seguido de la palabra clave, despues se coloca el parametro que dicha instruccion requiere. (en el campo KEY) "
      );
    });
  })
  .catch((err) => {
    console.log("Error al conectarse con la base de datos", err);
  });
