var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var tweetSchema = Schema({
  text: String,
  author: String,
});

module.exports = mongoose.model("tweet", tweetSchema);
