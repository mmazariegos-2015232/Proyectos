var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var userSchema = Schema({
  name: String,
  username: String,
  password: String,
  followers: [{ type: Schema.Types.ObjectId, ref: "user" }],
  followed: [{ type: Schema.Types.ObjectId, ref: "user" }],
  email: String,
  phone: String,
  address: String,
  tweets: [{ type: Schema.Types.ObjectId, ref: "tweet" }],
});

module.exports = mongoose.model("user", userSchema);
