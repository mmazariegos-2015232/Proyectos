"use strict";

var Employee = require("../models/employees.model");

function saveEmployee(req, res) {
    var employee = new Employee();
    var params = req.body;

    if (
        params.name &&
        params.lastName &&
        params.job &&
        params.phone &&
        params.email &&
        params.address &&
        params.age
    ) {
        Employee.findOne(
            {
                $or: [{ phone: params.phone, email: params.email }]
            },
            (err, employeeFind) => {
                if (err) {
                    res.status(500).send({ message: "Error general.", err });
                } else if (employeeFind) {
                    res.send({
                        message:
                            "Los datos no son correctos o no estan disponibles, por favor intente con otros."
                    });
                } else {
                    employee.name = params.name;
                    employee.lastName = params.lastName;
                    employee.job = params.job;
                    employee.phone = params.phone;
                    employee.email = params.email;
                    employee.address = params.address;
                    employee.age = params.age;

                    employee.save((err, employeeSaved) => {
                        if (err) {
                            res.status(500).send({
                                message: "Error general.",
                                err
                            });
                        } else if (employeeSaved) {
                            res.send({
                                message: "Registro guardado exitosamente.",
                                employeeSaved
                            });
                        } else {
                            res.status(418).send({
                                message:
                                    "No ha sido posible guardar el registro."
                            });
                        }
                    });
                }
            }
        );
    } else {
        res.send({ message: "Ingrese todos los datos requeridos." });
    }
}

function removeEmployee(req, res) {
    var employeeId = req.params.id;

    Employee.findByIdAndRemove(employeeId, (err, removed) => {
        if (err) {
            res.status(500).send({ message: "Error general" });
        } else if (removed) {
            res.send({
                message: "El registro ha sido removido de forma exitosa.",
                removed
            });
        } else {
            res.send({ message: "No se ha podido eliminar el registro." });
        }
    });
}

function updateEmployee(req, res) {
    var employeeId = req.params.id;
    var update = req.body;

    Employee.findByIdAndUpdate(
        employeeId,
        update,
        { new: true },
        (err, updated) => {
            if (err) {
                res.status(500).send({ message: "Error general.", err });
            } else if (updated) {
                res.send({
                    message: "Registro actualizado de manera correcta.",
                    updated
                });
            } else {
                res.status(404).send({
                    message: "no se ha podido actualizar el registro."
                });
            }
        }
    );
}

//funcion para buscar por coincidencia
function matchSearch(req, res) {
    var params = req.body;

    if (params.name || params.job || params.lastName || params.email) {
        Employee.find(
            {
                $or: [
                    { name: { $regex: "^" + params.name, $options: "i" } },
                    {
                        lastName: {
                            $regex: "^" + params.lastName,
                            $options: "i"
                        }
                    },
                    { job: { $regex: "^" + params.job, $options: "i" } },
                    { email: { $regex: "^" + params.email, $options: "i" } }
                ]
            },
            (err, employeeMatch) => {
                if (err) {
                    res.status(500).send({ message: "Error general.", err });
                } else if (employeeMatch) {
                    res.send({ employee: employeeMatch });
                } else {
                    res.status(404).send({
                        message: "No ha sido posible encontrar el empleado."
                    });
                }
            }
        );
    } else {
        res.status(404).send({
            message: "Ingrese un dato para realizar la busqueda."
        });
    }
}

function listEmployees(req, res) {
    Employee.find({}, (err, employees) => {
        if (err) {
            res.status(500).send({ message: "Error general.", err });
        } else if (employees) {
            res.send({ employee: employees });
        } else {
            res.send({ message: "Sin registros." });
        }
    });
}

module.exports = {
    saveEmployee,
    removeEmployee,
    updateEmployee,
    matchSearch,
    listEmployees
};
