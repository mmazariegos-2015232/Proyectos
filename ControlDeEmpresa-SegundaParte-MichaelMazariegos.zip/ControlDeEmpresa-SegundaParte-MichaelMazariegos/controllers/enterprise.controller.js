"use strict";

var Enterprise = require("../models/enterprise.model");
var Employee = require("../models/employees.model");

function saveEnterprise(req, res) {
    var enterprise = new Enterprise();
    var params = req.body;

    if (
        params.name &&
        params.address &&
        params.phone &&
        params.email &&
        params.businessActivity &&
        params.socialPurpose
    ) {
        Enterprise.findOne(
            {
                $or: [
                    {
                        name: params.name,
                        phone: params.phone,
                        email: params.email
                    }
                ]
            },
            (err, enterpriseFind) => {
                if (err) {
                    res.status(500).send({ message: "Error general.", err });
                } else if (enterpriseFind) {
                    res.send({
                        message:
                            "Algunos de los campos no estan permitidos o no son correctos, por favor intenta con uno nuevo."
                    });
                } else {
                    enterprise.name = params.name;
                    enterprise.address = params.address;
                    enterprise.phone = params.phone;
                    enterprise.email = params.email;
                    enterprise.businessActivity = params.businessActivity;
                    enterprise.socialPurpose = params.socialPurpose;

                    enterprise.save((err, enterpriseSaved) => {
                        if (err) {
                            res.status(500).send({
                                message: "Error general.",
                                err
                            });
                        } else {
                            if (enterpriseSaved) {
                                res.send({ admin: enterpriseSaved });
                            } else {
                                res.status(404).send({
                                    message:
                                        "no se ha podido guardar el registro",
                                    err
                                });
                            }
                        }
                    });
                }
            }
        );
    } else {
        res.send({ message: "Ingrese los datos requeridos." });
    }
}

function removeEnterprise(req, res) {
    let enterpriseId = req.params.id;
    Enterprise.findByIdAndRemove(enterpriseId, (err, enterpriseRemoved) => {
        if (err) {
            res.status(505).send({ message: "Error general.", err });
        } else if (enterpriseRemoved) {
            res.send({
                message: "se elimino el registro de manera correcta.",
                enterpriseRemoved
            });
        } else {
            res.status(418).send({
                message:
                    "No ha sido posible eliminar el registro, intentelo mas tarde."
            });
        }
    });
}

function updateEnterprise(req, res) {
    var enterpriseId = req.params.id;
    var update = req.body;

    Enterprise.findByIdAndUpdate(
        enterpriseId,
        update,
        { new: true },
        (err, updated) => {
            if (err) {
                res.status(500).send({ message: "Error general.", err });
            } else if (updated) {
                res.send({ message: "Actualizado exitosamente.", updated });
            } else {
                res.status(418).send({
                    message: "No ha sido posible Actualizar el registro."
                });
            }
        }
    );
}

//Contar con cuantos empleados cuenta la empresa.
function countEmployees(req, res) {
    var enterpriseId = req.params.id;
     Enterprise.findById(enterpriseId, (err, find) => {
        if (err)
            return res.status(500).send({ message: "Error general.", err });
        if (!find)
            return res.status(404).send({
                message: "no hay empleados laborando en la empresa."
            });
        console.log(find.length);
        return res
            .status(200)
            .send({ Cantidad_De_Empleados: find.employees.length });
    }); 

    /* Employee.count({ enterprise: enterpriseId }, (err, employees) => {
        if (err) {
            res.status(500).send({ message: "Error general.", err });
        } else if (employees) {
            res.send({ "empleados laborando": employees });
        } else {
            res.send({ message: "uh oh ha habido un problema." });
        }
    }); */
}

// funcion para enbedir los empleados a la empresa.
function setEmployee(req, res) {
    let enterpriseId = req.params.id;
    let params = req.body;
    let employees = new Employee();

    Enterprise.findById(enterpriseId, (err, enterpriseOk) => {
        if (err) {
            res.status(500).send({ message: "Error general" });
        } else if (enterpriseOk) {
            if (params.name && params.phone) {
                employees.name = params.name;
                employees.lastName = params.lastname;
                employees.job = params.job;
                employees.phone = params.phone;
                employees.email = params.email;
                employees.address = params.address;
                employees.age = params.age;

                Enterprise.findByIdAndUpdate(
                    enterpriseId,
                    { $push: { employees: employees } },
                    { new: true },
                    (err, enterpriseUpdated) => {
                        if (err) {
                            res.status(500).send({
                                message: "Error general.",
                                err
                            });
                        } else if (enterpriseUpdated) {
                            res.send({ enterprise: enterpriseUpdated });
                        } else {
                            res.status(404).send({
                                message:
                                    "No ha sido posible actualizar el registro."
                            });
                        }
                    }
                );
            } else {
                res.status(200).send({
                    message:
                        "Ingese los datos minimos requeridos para agregar un empleado."
                });
            }
        } else {
            res.status(404).send({
                message: "Empleado no registrado, por favor intente de nuevo."
            });
        }
    });
}

function listEnterprises(req, res) {
    Enterprise.find({}, (err, enterprises) => {
        if (err) {
            res.status(500).send({ message: "Error general.", err });
        } else if (enterprises) {
            res.send({ enterprises: enterprises });
        } else {
            res.send({ message: "Sin registros." });
        }
    });
}

/*///////////////////////-- CRUD de las sucursales de las distintas empresas --\\\\\\\\\\\\\\\\\\\\\\\\*/

module.exports = {
    saveEnterprise,
    removeEnterprise,
    updateEnterprise,
    countEmployees,
    setEmployee,
    listEnterprises
};
