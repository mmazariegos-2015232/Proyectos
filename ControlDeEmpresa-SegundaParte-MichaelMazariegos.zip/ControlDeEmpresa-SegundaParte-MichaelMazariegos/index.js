"use strict";

var mongoose = require("mongoose");
var app = require("./app");
var port = 3800;

mongoose.Promise = global.Promise;

mongoose
    .connect("mongodb://localhost:27017/Enterprise", {
        useNewUrlParser: true,
        useUnifiedTopology: true
    })
    .then(() => {
        console.log("Conexion a la DB correcta.");
        app.listen(port, () => {
            console.log("Servidor de express corriendo", port);
        });
    })
    .catch(err => {
        console.log("Error al conectar.", err);
    });
