"use strict";

var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var enterpriseSchema = Schema({
    name: String,
    address: String,
    phone: String,
    email: String,
    businessActivity: String,
    socialPurpose: String,
    employees: [
        {
            name: String,
            lastName: String,
            job: String,
            phone: String,
            email: String,
            address: String,
            age: Number
        }
    ]
});

module.exports = mongoose.model("enterprise", enterpriseSchema);
