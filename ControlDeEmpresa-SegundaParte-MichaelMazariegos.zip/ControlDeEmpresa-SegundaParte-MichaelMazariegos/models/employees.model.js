"use strict";

var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var employeesSchema = Schema({
    name: String,
    lastName: String,
    job: String,
    phone: String,
    email: String,
    address: String,
    age: Number
});

module.exports = mongoose.model("Employees", employeesSchema);
