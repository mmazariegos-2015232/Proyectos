"use strict";

var express = require("express");
var enterpriseController = require("../controllers/enterprise.controller");
var api = express.Router();

api.post("/saveEnterprise", enterpriseController.saveEnterprise);
api.delete("/removeEnterprise/:id", enterpriseController.removeEnterprise);
api.put("/updateEnterprise/:id", enterpriseController.updateEnterprise);
api.get("/listEnterprises", enterpriseController.listEnterprises);

//Contar los empleados de la empresa.
api.post("/countEmployees/:id", enterpriseController.countEmployees);

//Asignar empleados a la empresa
api.put("/setEmployee/:id", enterpriseController.setEmployee);

module.exports = api;
