"use strict";

var express = require("express");
var employeeController = require("../controllers/employees.controller");
var api = express.Router();

api.post("/saveEmployee", employeeController.saveEmployee);
api.delete("/removeEmployee/:id", employeeController.removeEmployee);
api.put("/updateEmployee/:id", employeeController.updateEmployee);
api.get("/listEmployees", employeeController.listEmployees);

// buscar empleados por medio de coincidencias
api.post("/matchSearch", employeeController.matchSearch);
module.exports = api;
